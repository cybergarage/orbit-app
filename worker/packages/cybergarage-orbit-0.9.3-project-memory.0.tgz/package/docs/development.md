# Development

This document explains how to set up the Orbit repository, run the CLI from
source, and validate changes. It is intended for contributors and maintainers
working on the agent framework or its CLI and GUI applications.

## Prerequisites

- Node.js 20.19 or newer
- npm

## Setup

Clone the repository, change to its root directory, and install the locked
dependencies:

```sh
npm ci
```

`package-lock.json` is the authoritative dependency lockfile. Use npm when
adding or updating dependencies, and include the resulting lockfile changes.

## Run the development CLI

Run Orbit directly from the TypeScript sources with:

```sh
./bin/dev.js
```

Pass CLI arguments after the script name. For example, to display help:

```sh
./bin/dev.js --help
```

On Windows, use the corresponding command script:

```bat
bin\dev.cmd --help
```

The development launcher uses `ts-node`, so rebuilding is not required after
each source change.

## Build and run the compiled CLI

Compile the TypeScript sources into `dist/`:

```sh
npm run build
```

Then run the compiled CLI with:

```sh
./bin/run.js --help
```

Do not edit files in `dist/` or `oclif.manifest.json` by hand. They are
generated outputs.

## Run the local GUI application

The GUI client is bundled as part of the normal build, so build Orbit before
starting the application:

```sh
npm run build
./bin/run.js gui
```

The command prints a loopback URL containing a temporary capability token.
Open that exact URL in a browser. Orbit selects an available port by default;
pass `--port` to use a fixed port:

```sh
./bin/run.js gui --port 4100
```

Provider and model flags can be passed to the same command. For example:

```sh
./bin/run.js gui --provider ollama --model llama3.1
```

When Ollama is selected without a model, CLI and GUI startup inspect the local
Ollama model list and select the first installed model that reports tool
support. Orbit has no hard-coded Ollama default. See [Settings](settings.md) for
the complete selection and failure behavior.

Press Ctrl+C in the starting terminal to stop the application and close its
active agents, MCP clients, and session recorders. Re-run `npm run build` after
changing the React client or server source. See [Local GUI](gui.md) for session,
diagnostics, and security details.

## Configuration

Orbit supports OpenAI, Anthropic, and Ollama. Configure the provider, model,
credentials, and optional MCP servers as described in [Settings](settings.md).
Keep real credentials out of source files, tests, documentation, logs, and
commits.

## Project structure

- `src/index.ts`: package entry point
- `src/apps/cli/`: oclif commands
- `src/apps/cli-flags.ts`: shared CLI flag handling
- `src/core/`: reusable runtime and public library implementation
- `src/core/models/adapters/`: provider-specific model adapters
- `src/core/tools/`: tool contracts, registry, runtime, and built-in coding tools
- `src/core/thread.ts`: event-driven thread API for GUI integrations
- `test/`: Mocha and Chai tests mirroring the source areas
- `docs/README.md`: documentation map and content ownership rules
- `docs/architecture.md`: current implemented system and module map
- `docs/concepts/`: durable terminology, mental models, and explicitly labeled
  direction
- `docs/`: user and developer feature documentation
- `docs/adr/`: research-backed Architecture Decision Records
- `docs/research/`: dated, non-binding engineering investigations
- `bin/`: CLI launchers and repository maintenance scripts

Keep reusable behavior in `src/core/` and CLI-specific behavior in
`src/apps/cli/`. Relative TypeScript imports must use the emitted `.js`
extension.

Model adapters receive `ModelToolSpec` values and never executable tool
handlers. `ToolRegistry` combines built-in, custom, turn-scoped, and MCP
definitions; `ToolRuntime` validates and schedules calls. Add reusable tools
under `src/core/tools/` and keep provider-specific serialization in the model
adapter. See [Coding Tools](tools.md) for the public behavior.

Completed assistant messages keep their primary text in `Message.content` for
compatibility and may expose normalized `ModelOutputPart` values in
`ModelAssistantPayload.parts`. Adapters use these parts to preserve provider
state needed by later requests, such as Ollama thinking text and images.
Provider-native metadata that has no shared field belongs under
`ModelResponseMetadata.providerMetadata` and must remain JSON-serializable.

OpenAI currently uses Chat Completions. Adding a Responses API adapter requires
ordered output-item and continuation-state support; do not flatten Responses
items directly into a single text message. See
[Model Response and Tool Integration](adr/2026-08-23-model-response-tool-integration.md)
for the verified protocol differences and follow-up direction.

Model providers are registered through `ModelRegistry` rather than selected by
a factory switch. A provider registration supplies its name, model constructor,
and an optional default model:

```ts
import {registerModelProvider} from '@cybergarage/orbit'

registerModelProvider({
  name: 'custom',
  defaultModel: 'custom-default',
  create(model, provider) {
    return new CustomModel(model, provider)
  },
})
```

Register an external provider before loading workspace settings that select its
name. Provider-specific request serialization remains inside its `Model`
implementation. Generic `apiKey`, `apiKeyEnv`, and `host` connection fields are
available through the supplied `Provider`.

## Tests and validation

Run the narrowest relevant test while iterating. For example:

```sh
TS_NODE_PROJECT=tsconfig.test.json npx mocha --forbid-only "test/core/thread.test.ts"
```

Before submitting a change, run the complete validation set:

```sh
npm run headers:check
npm run build
npm test
```

`npm test` runs Prettier and ESLint before the test suite. These commands can
rewrite files, so review the resulting diff afterward. New TypeScript files
must include the standard copyright and SPDX header; run
`npm run headers:apply` to add missing headers.

The `tests` GitHub Actions workflow runs package checks and the Ubuntu unit
test matrix on every push. Use its manual `workflow_dispatch` trigger to run
the separate Windows unit test matrix when investigating Windows behavior.
Each job has a 30-minute timeout so a stalled test process does not occupy a
runner for the platform's six-hour default limit. The shared storage Windows
compatibility matrix is confirmed in the [Windows acknowledgement ADR](adr/2026-10-04-windows-storage-acknowledgement.md);
platform filesystem and privilege limits remain explicit there.

### Live model integration tests

After `npm run build`, run `npm run test:models` to exercise the real model
adapters. These tests are separate from the deterministic `npm test` suite;
they send real requests and cloud providers may incur API charges.

Keep test environment files at the repository root using these names:

| File | Purpose | Git |
| --- | --- | --- |
| `.env.test.local` | Local test credentials and model overrides | Ignored |
| `.env.test.<provider>.local` | Optional provider-specific local overrides, such as `.env.test.openai.local` | Ignored |
| `.env.test.example` | Shared variable names and clearly fake placeholder values | Tracked when added |

Use `.local` as the final suffix for private test environment files. Keep real
credentials out of example files and restrict local credential files to their
owner (for example, `chmod 600 .env.test.local` on POSIX systems).

These files are not loaded automatically. In a POSIX shell, load the desired
file before running the tests:

```sh
set -a
. ./.env.test.local
set +a
npm run test:models
```

| Provider | Execution condition | Optional model selection |
| --- | --- | --- |
| OpenAI | Nonempty `ORBIT_TEST_OPENAI_API_KEY` | `ORBIT_TEST_OPENAI_MODEL` (otherwise Orbit's default) |
| Anthropic | Nonempty `ORBIT_TEST_ANTHROPIC_API_KEY` | `ORBIT_TEST_ANTHROPIC_MODEL` (otherwise Orbit's default) |
| Ollama | Server at `http://127.0.0.1:11434` with an installed tool-capable model | `ORBIT_TEST_OLLAMA_MODEL` (otherwise the first installed model reporting tool support) |

Missing test keys, a stopped local Ollama server, and installations without a
tool-capable model appear as pending tests. An explicitly selected Ollama model
requires a running server, must be installed, and must report tool support;
otherwise discovery fails. Tests never download models or load workspace
settings, sessions, or MCP servers. Ordinary `OPENAI_API_KEY` and
`ANTHROPIC_API_KEY` variables do not enable these tests. Once enabled,
authentication, API, discovery, and generation errors fail the test. Each
discovery request has a three-second deadline; each generation request has a
two-minute deadline. The selected provider and model are printed for each suite.

Each enabled provider runs three scenarios, with five generation requests in
total and an output cap of 2,048 tokens per request:

- A nonempty assistant response with normalized provider and model metadata,
  plus output parts when exposed by the adapter.
- A two-request conversation that recalls a fresh identifier from the first user
  message after replaying the assistant response.
- A tool call with checked name, arguments, ID, and optional normalized output part,
  followed by a tool result and final response. The result contains a fresh code
  generated after the call, and the final response must include that code without
  another tool call.

These are bounded integration checks, not broad model-quality evaluations. Tool
selection and identifier copying still depend on model behavior; failures remain
visible without automatic retries. The tool is a synthetic lookup: these tests
exercise adapter serialization and response normalization, not Agent tool
scheduling or real filesystem/MCP effects. Cancellation forwarding and Ollama
listener cleanup are checked with injected SDK clients in
`test/core/model-cancellation.test.ts`, without live requests.

Run `npm run test:models:unit` to verify execution conditions and Ollama capability
selection without model services or credentials. The existing `test:e2e:ollama`
command remains a separate Docker-based coding evaluation with explicitly
selected models.

### Managed execution surface fixtures

After building, run these isolated fixtures from the repository root:

```sh
node test/apps/cli/fixtures/managed-interactive.mjs
node test/apps/gui/fixtures/transport-faults.mjs
```

The first needs a real terminal. Type `edit`, answer `y`, `n`, or Ctrl+C at
confirmation, then type `/exit`. It prints the outcome and whether the temporary
file changed. Use separate sessions for approval and denial/cancellation checks.
It deliberately selects `file-sync`; this does not verify the stronger default.

The GUI fixture prints a loopback URL. Create a session, send `edit`, wait for
the preview, and approve once. Its local proxy disconnects SSE, delays an old
snapshot, returns HTTP 503 once, and replays duplicate/out-of-order snapshots.
Verify completion and disappearance of the reconnect notice. Terminate the
fixture with SIGTERM to print counters and remove its temporary data. Both
fixtures inject models and avoid provider credentials and real user sessions.

The separate diagnostic probe below tests simultaneous reclamation of a stale
SessionRecorder lock. **It currently exits 1 because both writers acquire the
same session.** This is an unresolved concurrency defect, not a passing regression
test; see the [journal ADR](adr/2026-09-07-required-execution-journal.md).

```sh
node test/core/execution/fixtures/stale-lock-race.mjs
```

It synchronizes two child processes after both read the dead owner's lock,
then lets them reclaim it in order. It kills only its own children and removes
its temporary directory. Keep this evidence distinct from `npm test` results.

## Releases and npm packages

See [Versioning](versioning.md) for milestone and compatibility policy.
The npm package is `@cybergarage/orbit`; the executable stays `orbit`.
Pushes do not create releases or publish packages automatically; both publication
workflows require an explicit manual dispatch.

1. Update `package.json` and the root metadata in `package-lock.json` together.
   Update the example's exact dependency and the relevant release documentation.
2. Run `npm run headers:check`, `npm run build`, `npm test` and
   `npm run test:package`. The latter packs a real tarball and installs it into
   an independent TypeScript consumer with no source-path aliases. It checks
   imports, CLI help, durable sessions, run retries, approval/denial, cancellation,
   logs and restart/resume without provider credentials. It also compiles and runs
   a public-API Rename consumer against the installed tarball, checking Session
   title metadata, Project names, expected-revision conflicts and exact retries.
   A second public-API consumer compiles initialization types and executes each
   scope against newly synthesized temporary data, checks refused consent and
   retained workspaces, and verifies the installed initialization CLI help.
   It needs registry access to install dependencies. It does not test live models or production storage.
3. Run `npm run docs:commands` after building to regenerate the oclif
   sections in `docs/cli.md`. Review all generated changes and run `git diff --check`.
4. Commit the reviewed change and create/push `v<package-version>` for that
   commit. Run the `Create GitHub release` workflow with that existing tag.
5. Run `Publish npm package` with the same released tag and the exact confirmation
   `publish`. Configure the repository's `NPM_TOKEN` with current npm publishing
   permissions. The workflow checks the version, tag, release, test suite and
   independent package consumer before publishing.

`prepack` always builds the runtime and GUI and generates the CLI manifest.
It does not regenerate tracked documentation. `files` limits the tarball to
runtime outputs, launchers, maintained Markdown guides and example source.
`publishConfig` specifies public access and the npm registry.

For a maintainer publishing locally after the same release checks:

```sh
ORBIT_RELEASE_DIR=/path/to/release-artifacts npm run test:package
npm publish /path/to/release-artifacts/cybergarage-orbit-VERSION.tgz --access public
```

Inspect the packed file list before publishing; verify the registry version and
GitHub tag afterward. A version that has been published must not be reused.
`ORBIT_RELEASE_DIR` retains the exact tested tarball; without it the temporary
consumer and tarball are removed. On Windows, set that environment variable
using your shell's syntax before running the check.
The package's first publication may require interactive npm authentication/2FA.
Never put credentials in repository files or release logs.

Add or update deterministic, isolated tests for every behavioral change. Stub
model providers, MCP services, and other external boundaries instead of making
live network requests.

## Documentation model

Use the [Documentation Map](README.md) to choose the authoritative home for a
change:

- concepts define durable vocabulary, mental models, and invariants;
- current architecture describes the repository as implemented today;
- feature guides describe current user and integration behavior;
- research preserves dated evidence and non-binding analysis; and
- ADRs preserve significant decisions, rationale, and lifecycle evidence.

Directional concepts must be labeled explicitly. Do not add an unimplemented
target design to `architecture.md`, and do not turn a research recommendation
or concept page into an implicit decision.

## Architecture decision records

Use `docs/adr/` for research-backed Architecture Decision Records (ADRs).
These records preserve the evidence, alternatives, rationale, consequences, and
implementation history behind architecturally significant decisions. They are
not authoritative user documentation and do not replace updates to the README,
API documentation, or feature-specific guides.

An ADR is appropriate when a choice materially affects system structure,
public or provider contracts, persistent formats, security or privacy
boundaries, cross-cutting runtime behavior, major dependencies, or something
costly to reverse. Do not create ADRs for routine fixes, local refactors,
progress reports, chat transcripts, or temporary plans.

Before adding a record, search the existing decisions and use the repository
skill at `.agents/skills/architecture-decision-record/SKILL.md`. The
[Architecture Decision Records](adr/README.md) index defines the complete
metadata schema, required sections, status values, and lifecycle.

Name a new record using its proposal date and a concise lowercase English topic
slug:

```text
docs/adr/YYYY-MM-DD-<topic>.md
```

Keep the filename while the decision advances from proposal through
implementation. Create a new dated record only for a distinct decision or a
material re-evaluation that supersedes an accepted decision.

Every ADR must separate decision status from implementation status. A proposal
can be accepted before it is implemented, rejected without implementation, or
only partially delivered. Keep `decision-date` null while the ADR is proposed
and set it to the explicit acceptance or rejection date when changing a new ADR
to either status. Do not derive it automatically from
`implementation-completed-date`; those dates match only when the events occur
on the same day. Migrated historical ADRs may retain a null `decision-date`
when the original decision date was not recorded. Use ISO 8601 dates and full
40-character commit hashes. Do not infer missing historical acceptance dates
or source revisions.

Put `Purpose`, `Decision`, and `Consequences` before detailed research. Follow
them with the problem context, decision drivers, external implementation
research, considered options, implementation and confirmation evidence,
follow-up work, and references. Keep one cohesive decision per record and
clearly distinguish verified facts, inferences, proposals, and future work.

For decisions about agent runtimes, models, tools, sessions, context assembly,
CLI or GUI agent workflows, persistence, or observability, investigate Codex
and Pi Coding Agent by default. Pin inspected source to an exact version, tag,
or full commit; list the relevant source files; and state both what Orbit should
adopt and what it should not. If either implementation is not relevant, explain
why rather than silently omitting it. Use primary source and official
documentation wherever possible.

Commit the proposed ADR before implementation. After implementation commits
exist, use a later documentation commit to record their full hashes, the
completion date, confirmation evidence, and completed implementation status. A
separate finalization commit is necessary because a commit cannot record its
own final hash in a tracked file.

Preserve the accepted context, decision, and original rationale. Metadata,
implementation evidence, confirmation results, and newly observed consequences
may be added later, but a material change requires a new ADR that marks and
links the original as superseded. Current code and maintained documentation
remain authoritative for implemented behavior.

## Documentation changes

Update the relevant documentation when changing CLI behavior, settings, public
APIs, or integration contracts. The interactive command reference is generated
from `docs/interactive.adoc` and `docs/data/interactive.csv`; update those
sources rather than editing only `docs/interactive.md`.

When runtime structure changes, update `docs/architecture.md`. When a change
affects shared terminology or invariants, update the relevant document under
`docs/concepts/` and its glossary entry. Record the decision history in an ADR
when the change is architecturally significant; keep dated investigation
evidence in `docs/research/`.

The CLI reference in [CLI Reference](cli.md) is generated by oclif from the
command definitions in `src/apps/cli/`. After changing command metadata, run:

```sh
npm run build
npm run docs:commands
```

`docs:commands` refreshes the manifest, then runs
`oclif readme --readme-path docs/cli.md`. It replaces the `usage` and `commands`
marker sections in that file; edit command definitions rather than generated
sections. `make oclif-docs` uses the same npm script. The root README is maintained
by hand as the framework introduction. Review generated differences before
committing them.

## Test complexity and SonarQube Cloud

ESLint disables only its cyclomatic `complexity` rule for
`test/**/*.{ts,mjs}`, `e2e/**/*.test.mjs`, and `e2e/**/*.e2e.mjs` in
[`eslint.config.mjs`](../eslint.config.mjs). Production complexity, other test
lint rules, security/reliability checks, and coverage settings remain in scope.
This ESLint override does not configure SonarQube Cloud.

Orbit currently receives a SonarQube Cloud check through its GitHub integration,
without a repository scanner workflow or properties file. This indicates
automatic analysis; the analysis-method setting itself is server-owned. Automatic
analysis ignores `sonar-project.properties`; `.sonarcloud.properties` supports a
limited set of scope settings, not `sonar.issue.ignore.multicriteria`. Do not add
an ineffective rule-ignore property to either file or switch analysis methods
without a separate integration decision. See the official
[automatic analysis documentation](https://docs.sonarsource.com/sonarqube-cloud/analyzing-source-code/automatic-analysis).

Sonar's source/test classification should keep test code analyzed as test code,
not exclude it from analysis. The repository's unit-test root is `test`, with
integration and E2E scripts under `e2e`. Preserve the existing source/test and
coverage scope when adding rule-specific exceptions. No scope exclusions or
coverage exclusions are configured by this change.

If Sonar reports test-only cognitive complexity, the supported automatic-analysis
option is project **Administration > General Settings > Analysis Scope > Issues >
Ignore Issues on Multiple Criteria**. Add the exact rule and file-path pair:

| Rule key | File path pattern | Purpose |
| --- | --- | --- |
| `typescript:S3776` | `test/**/*` | Exempt only cognitive complexity inside the unit-test tree |

Preserve existing criteria and use a separate entry for every rule/path pair;
`resourceKey` does not accept comma-separated paths. Add `typescript:S1541`
(cyclomatic complexity) with `test/**/*` only if that rule is actually reported
for tests. Do not use `*` as the rule key or a production path as the file pattern.
The official [advanced exclusions documentation](https://docs.sonarsource.com/sonarqube-cloud/managing-your-projects/project-analysis/setting-analysis-scope/advanced-exclusions)
describes this server-side configuration. Account/project settings were not
changed by the repository update.

As inspected on PR #7 on 2026-10-14, Sonar reported `typescript:S3776` only in
production `src/core/projects/service.ts`, not in tests; `typescript:S1541` was
not reported. That production finding stays visible. Test findings were
`typescript:S5906` (dedicated assertion matchers), which this complexity policy
does not suppress. `typescript:S7503` (an async function without await) was also
reported in production. Consult the current PR analysis for changing counts.

The workflows use official `actions/checkout@v7` and `actions/setup-node@v7`
releases on GitHub-hosted runners. Their Node 24 action runtime is independent
of Orbit's tested Node versions; self-hosted runners need at least v2.327.1.
Checkout's fork-PR guard does not affect the existing push/workflow-dispatch
triggers. Setup-node v7 removes the dummy `NODE_AUTH_TOKEN` fallback, so npm
publication configures its registry only immediately before publication, using
the existing token; public dependency installation and tests run before that
configuration. No release or publication workflow is dispatched by this update.
See the official [checkout README](https://github.com/actions/checkout) and
[setup-node README](https://github.com/actions/setup-node) for migration details.
