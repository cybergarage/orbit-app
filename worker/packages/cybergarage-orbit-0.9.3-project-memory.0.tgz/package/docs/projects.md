# Projects and Curated Memory

## Implementation status

Project catalog storage, registered session coordination, curated memory and GUI
controls are implemented in core and the local GUI. CLI conversation workflows
remain projectless. See the [catalog decision](adr/2026-09-22-project-catalog-and-session-membership.md)
and [memory decision](adr/2026-09-22-project-memory-context.md) for rationale and
qualification limits.

## GUI workflow

Start `orbit gui` after building. The sidebar orders **New Chat**, **Project**,
and **Recent**. The top-level **New Chat** creates an unassigned conversation;
**Recent** lists unassigned conversations newest first without duplicating
conversations shown under Projects.

The **+** beside **Project** opens a creation dialog with a name and an optional
absolute working directory. A blank directory uses the GUI's startup directory.
Two Projects may use the same directory. Click a Project row to expand or
collapse its conversations without changing the conversation currently open.
Each expanded Project has its own paginated list and **Show more** action.
Failed lists display a retry action rather than appearing empty.

Hover over a Project, or focus it with the keyboard, to expose its **New Chat**
icon. This creates a separate persisted conversation in that Project and opens
it in the conversation pane. Its cwd, workspace settings, context files and
Skill catalog are resolved for that thread. Resume retains the saved cwd and
model. Changing Project navigation leaves existing runs associated with their
original threads.

Right-click a Project, or select its **…** button, for **New Chat**,
**Project settings…**, and **Archive project**. Settings edit the name and default
directory; changing the directory affects only future conversations. Archive
hides the Project from the active list and blocks new Project work; existing
runs finish. The **Project** heading's **…** menu switches between active and
archived Projects. Archived Projects offer **Unarchive project**. Core project deletion is available through the application service; GUI deletion controls are not exposed.

Right-click any conversation, or use its **…** button, and choose
**Move to project…**. Select an active Project or **Unassigned** to attach, move,
or detach that conversation. The action targets the selected menu row, even
when another conversation is open. Moving the open conversation preserves its
visible history and reopens its idle host thread for continued use. Its historical
messages and recorded cwd remain. Source-derived memory rows in the old Project
are retired instead of copied. Active or quarantined conversations cannot be
moved. Missing/deleted sources are shown as unavailable. A creation reservation
interrupted before membership commit is labeled incomplete under Recent and
cannot start a run until reconciled; its retry action retains the original
creation operation ID.

Menus support arrow-key navigation and Escape. Settings and movement dialogs
support keyboard focus traversal and Escape; pending writes prevent duplicate
submission. Membership changes retain revision checks and retry operation IDs.

## Application integration

Pass a `projectStore` to `OrbitApplicationService` to enable coordination. The
application owns its shutdown. Existing synchronous `createThread()` stays
projectless. Use `await createProjectThread(projectId, {operationId})` for a
Project; retain the UUID operation ID across retries. Core reserves that ID,
synchronizes the registered transcript, and commits membership before returning
a Thread. An interrupted attempt retains its reservation and any unassigned
transcript. Retry with the same Project and operation ID; a changed Project
revision or conflicting header requires explicit inspection, not an overwrite.

`service.projects` exposes metadata, membership and scoped listing operations.
Membership mutations require both the source Project and expected revision.
The host closes an idle writer and acquires the registered session claim before
committing the catalog update. Project-aware deletion marks a source unavailable
before the existing session deletion workflow and cleans membership afterward.
Project listing also reconciles completed CLI deletion markers under writer
ownership, unlinks the deleted source and retires derived notes. An unfinished
deletion remains unavailable; corrupt deletion evidence raises an error.

The optional `resolveProjectRuntime(cwd)` hook lets an embedding host resolve
per-thread agent options. The default reads workspace settings and instructions;
an explicitly supplied execution policy retains its roots. The GUI host explicitly
sets workspace-confirm roots to each thread's cwd. Project membership itself
does not grant tool permission.

REST routes use the existing loopback/token/origin boundary. `/api/projects`
provides paginated metadata, `/api/projects/:id/sessions` lists scoped
conversations, `/api/projects/:id/threads` creates them, and
`/api/sessions/:id/membership` performs explicit moves. Scoped resume checks
membership server-side. Mutation responses carry revisions; `project.changed`
invalidates browser lists, and reconnect reloads authoritative lists. CLI
`exec`, `resume` and interactive workflows do not open the catalog.

## Catalog adapters

Core exports `ProjectStore`, `MemoryProjectStore` and `SqliteProjectStore`.
Opening the SQLite adapter is explicit; importing Orbit does not open a catalog
or import the native binding. The binding runs in an owned worker. Always await
`close()`; it drains accepted requests before closing the database. Queue and
lock limits return retryable `ProjectStoreError` errors with code `busy`.

```typescript
import {SqliteProjectStore} from '@cybergarage/orbit'

const store = await SqliteProjectStore.open({file: '/example/data/projects.sqlite'})
try {
  const projects = await store.query({archived: false, kind: 'projects', limit: 50})
  console.log(projects)
} finally {
  await store.close()
}
```

Use a local filesystem on one host. Schema 1 uses WAL, foreign keys and FULL
synchronization, with an exclusive initialization transaction. Newer or corrupt
schemas are refused. The adapter does not repair damaged catalogs. Directory
synchronization is performed on Unix; portable directory synchronization is not
available through this API on Windows. Physical power-loss behavior and the
complete platform matrix have not been qualified.

`backup(destination)` uses SQLite's backup API and requires a new absolute
destination. Do not copy only a live database file: committed pages can still be
in its WAL. A catalog backup does not include session transcripts or journals.

## Low-level transaction contract

`mutate(operationId, mutation)` takes a UUID operation ID and expected revision.
An exact retry returns the original result, even after later edits. Reusing the
ID with different input or submitting an outdated revision fails with
`conflict`. Changes and operation results commit together. Read operations are
transactional. Project lists use ID order with an exclusive `after` cursor;
membership lists use session ID order within a registered storage pair.

Project IDs are independent of directory names. Membership uses the registered
storage pair ID and session ID. An unlinked membership retains its revision to
prevent stale attachment requests from succeeding. Pending creation reservations
retain their chosen directory and Project revision; a changed Project blocks
reservation completion without erasing the pending record.

The store is a trusted host boundary, not a model tool or an HTTP handler.
Session writer ownership, source availability and source digest verification
must be enforced by the coordinating host before a catalog mutation. The store
alone does not grant access to a session or validate a user-provided excerpt.

Memory rows preserve immutable source references and retirement state. Writes
are limited to 128 active entries, 8 KiB per body and 1 MiB of active bodies per
Project. Catalog capture validates the membership revision and memory generation
transactionally. It records only the supplied snapshot digest; exact Run context
evidence resides in the execution journal. Storage and deterministic adapter
tests establish mechanics; they do not evaluate semantic recall quality.

## Curated memory workflow

Open a Project conversation and expand **Project memory**. Add a human-authored
note, or choose a source message and enter an exact excerpt. An optional edited
note preserves the original message reference and digest. Titles are limited to
256 characters; bodies to 8 KiB. The server resolves registered sessions itself
and rejects invented excerpts and browser-supplied paths.

For optional curated control, choose **Curated memory** in the GUI. Select notes to
prioritize them, then use **Preview next run** to inspect the exact rendered
context and exclusions. Selection is whole-entry: explicit selections first,
then most recently updated entries with ID tie-breaking, at most 16 entries and
2,048 tokenizer tokens. Explicit selections that cannot fit fail visibly;
automatic exclusions carry reasons. The configured model input policy still
validates the actual prepared request, including other context and tools.
A preview binds the memory generation; if notes change before admission, preview
again. Without a preview, a run captures the current eligible generation.

**Edit** changes future runs. **Stop using** retires a note; **Restore** checks
its linked sources again. Moving or unlinking a source conversation retires
its derived notes. Missing, changed or unavailable sources are excluded. Corrupt
or ambiguous source files cause a preparation error. Source reads are bounded
and coordinated with writer ownership; an active source can require a retry
or **Off**. Idle source threads may be closed during inspection and are reopened
when their next application run starts.

**Off** omits fresh memory for the next run. It cannot remove quotations already
in conversation history. **Show recorded snapshots** displays the exact context
recorded for previous runs, including notes later edited or retired. A recorded
snapshot alone does not prove the provider received it. Secure erasure is not
provided by retirement, deletion of a source, or turning memory off.

## Run context and integration

`service.projectMemory` provides `create`, `saveExcerpt`, `edit` and `prepare`.
Writes require a UUID operation ID; edits also require the observed entry
revision. Preserve operation IDs on network retries and use a new ID for changed
input. Source references are immutable. `service.previewProjectMemory` performs
non-capturing preparation; `service.projectContextHistory` reads recorded context.

Pass `memory: {mode: 'curated', selectedIds?, expectedGeneration?}` to
`service.startRun`, `startGraphRun`, or a managed Agent configured with the
coordinating memory service. Library callers default to off unless they opt in.
Low-level callers must retain ownership of the destination Session during
capture. A bare legacy `invoke` host cannot execute curated memory.

Capture revalidates membership and memory generation in one catalog transaction.
The execution journal then acknowledges `run-admitted` and `project-context`
before managed effects. Such runs use journal **v3**; ordinary runs continue to
use v1, and Graph runs without memory use v2. A journal may contain runs of all
three versions. Transcript versions are independent and are not upgraded merely
to use memory. Graph execution retains its explicit transcript migration rules.
Readers predating journal v3 cannot consume these runs and must not be used for
maintenance of affected journals.

The context record is bounded to 256 KiB and contains exact entries, revisions,
provenance, exclusions, rendered text and a digest. Admission stores a digest of
configuration that includes the context digest, never raw provider/MCP settings.
An interrupted admission without acknowledged context is reported as interrupted
preparation; recovery observes it rather than automatically dispatching it.
A repeated admitted request returns its prior run without capturing newer notes.

Each model request in the run receives one fixed user-role memory prefix. The
prefix is untrusted historical data, separate from system instructions, canonical
messages and compaction source history. Tool iterations and Agent Graph stages
reuse it; edits are visible only to later runs. Existing verified-interruption
preflight and prepared-request checks remain in force.

GUI REST endpoints include `/api/projects/:id/memory`, `/memory/excerpts`,
`/memory/:entryId`, `/api/threads/:id/memory/preview` and
`/api/sessions/:id/project-context`. The same capability, origin, payload and
schema checks protect them. `project.memory.changed` carries entry revision and
Project generation metadata. **Refresh notes** reloads authoritative entries;
a stale revision never silently overwrites another edit.

## Core project deletion

Use `service.deleteProject(id, {expectedRevision, operationId})` or
`service.projects.delete(id, options)` with the exact project UUID, observed
revision and a new UUID operation ID. An exact retry returns the original
project result even after deletion; changed input conflicts. A fresh operation
for a missing or already deleted ID fails with `missing`.

Deletion rejects any remaining project membership, including archived, active,
quarantined and unavailable sessions in any storage pair, and pending creation
reservations. Move or explicitly delete conversations first. No session deletion
is invoked implicitly. Successful deletion atomically removes the project,
its active/retired memories and committed reservations. Detached membership
revisions and prior operation results remain for retry and conflict detection.
Working directories and source files are never accessed or deleted.

The catalog transaction serializes deletion with membership, reservation,
memory and project changes. A failed transaction leaves the project intact;
an uncertain acknowledgement must be retried with the same operation ID.
Deleted projects disappear from catalog queries after restart. Earlier create
operation results are historical acknowledgements and cannot recreate a project.

`projects.listSessions(id, {archive, after, limit})` supports `active`, `archived`
and `all` archive filters. Omission means all for compatibility. It filters before
pagination, using the existing exclusive session-ID cursor. Session archive
preserves project membership and does not retire memories.

## CLI project lifecycle

The CLI uses the same persistent `projects.sqlite` catalog as the GUI, without
connecting a model or MCP server:

```sh
orbit project list --archive all
orbit project list --archive archived
orbit project sessions <PROJECT_ID> --archive archived
orbit project archive <PROJECT_ID>
orbit project unarchive <PROJECT_ID>
orbit project delete <PROJECT_ID> --force
```

All mutations require an exact Project ID. Unarchive restores active Project
availability. Archiving a Project retains its directory, memories and conversation
memberships; it does not change individual sessions' archive states. Lists default
to all archive states; `--archive active|archived|all` selects a state.
`project list` prints a JSON array ordered by ID. `project sessions` prints a JSON
page with membership, session and unavailable status plus an optional
`nextCursor`. Use `--after` with the last Project ID or returned session cursor
and `--limit` (1 to 200). Filters apply before pagination.

Project deletion removes only an empty catalog Project and its memories and
committed reservations. Any remaining conversation membership, including archived
or unavailable conversations across storage pairs, or pending creation reservation
blocks deletion. Explicitly move or delete conversations first. After using
`orbit delete` or `orbit session delete`, `orbit project sessions <PROJECT_ID>`
reconciles completed deletion markers before retrying Project deletion.
Working-directory and source files are never removed.

Interactive deletion names the exact Project and scope and defaults to No.
Non-interactive deletion requires `--force`; it does not bypass catalog revision,
reservation or dependency checks. A revision change during confirmation fails
rather than deleting a changed target. Unknown IDs, busy/closed/unavailable
catalogs and storage failures produce a failure exit status.

## Renaming projects

`ProjectService.rename(id, {name, expectedRevision, operationId})` updates only
the display name, revision and update timestamp in the catalog transaction.
Membership, archive state, directory and memory generation are preserved.
Renaming does not require the existing directory to be available. Names are
trimmed, contain 1–256 UTF-16 units and exclude control characters; Japanese and
internal spaces are supported. Existing revision and durable operation replay
rules apply, including exact retries after intervening updates.

```sh
orbit project rename <PROJECT_ID> --name "Design project"
orbit project rename <PROJECT_ID> --name "Design project" --expected-revision 1 --operation-id <UUID>
```

The CLI defaults to the observed revision and a new operation UUID. Supply both
original flags for an exact retry. Stale revisions fail instead of overwriting
another editor's changes.

The GUI's **Rename project…** menu and **Project settings…** name-only save calls the same service through
`POST /api/projects/:id/rename`. It accepts `name`, `expectedRevision` and
`operationId`. Settings updates through `PATCH /api/projects/:id` also accept
partial `name`, `directory` and `archived` fields; omitted values are preserved
inside the catalog transaction. Changing the directory affects only future
conversations. A name-only save never resubmits directory/archive state.

## Automatic knowledge

The GUI defaults new Project submissions to **Automatic memory**. Normal use
requires no manual note registration, note selection or preview. The host
reconciles completed, quiescent journal runs every five seconds and extracts
source-bound decisions, constraints, explicit corrections and verified facts.
Runs without a recorded Project context are not backfilled. Chats have no
shared knowledge pool. New conversations can start before extraction finishes;
they retain their admitted snapshot.

The supplementary Project memory panel offers **Stop automatic extraction**,
**Resume automatic extraction**, **Processing status and budgets**, editing,
retirement and source navigation. Stopping extraction preserves existing notes;
choose **Off** to omit memory from the next run. Retirement preserves a
tombstone so reprocessing cannot recreate the same candidate. Manual edits
remain authoritative. Weak replacements remain pending and are excluded from
selection. English words and Japanese character bigrams rank relevance before
freshness, with importance and whole-entry token limits retained.

Each attempt reserves at most 4,096 input and 1,024 output tokens before model
inference. Failed and interrupted attempts retain the reservation. Jobs allow
three attempts, with default lifetime Project limits of 100,000 input and
16,384 output tokens and 16 calls. A durable queue cap of 32 pending retryable jobs
postpones capture without blocking ordinary conversations. The typed `automation` catalog mutation can adjust these
limits without resetting accrued reservations. They are conservative token
allowances, not measured billing or a monetary cost guarantee. Provider prices
and provider enforcement may differ. The default tool-free extractor uses installed local `gemma4:12b` over loopback Ollama,
no tools, JSON output, a 1,024 output-token request limit and a 30-second timeout.
Known credential patterns are suppressed; detection is not a complete secret
scanner.

Catalog schema 2 adds `automation` and `extractions` tables transactionally to
schema 1. Existing Project, membership, memory, operation and reservation rows
are preserved. Unsupported schemas fail closed. Schema-1-only binaries cannot
open the upgraded catalog; do not downgrade against it. No backup or relocation
copy is performed. Saved-data/all initialization removes the catalog through
the existing target list; settings-only initialization retains knowledge and
jobs. Reported usage is recorded separately; reported overruns pause extraction.
Unknown usage retains the full reservation. Stopped in-flight work can settle
failed/discarded accounting, but cannot apply knowledge or start another call.
Oversized input is discarded before reserving a call. Limits cannot reset accrued usage.

The desktop app host coordinates canonical source leases across original storage
pairs and supplies a policy-2 frozen snapshot to disposable workers. Historical
policy-1 snapshots retain their same-pair validation. Logical Project membership,
not storageProjectId, defines sharing. The app guide documents its source-helper
namespace, lifecycle and unpublished local-package validation procedure.

Extractor comparison candidates are selected by relevance across all active
entries, with at most sixteen whole entries within the input budget. Untargeted
corrections are pending; lexical evidence of competing same-kind knowledge can
hold candidates with different titles. This is conservative uncertainty handling,
not a semantic contradiction oracle: vocabulary changes can miss conflicts and
generic overlap can hold compatible entries. A user need not supply an old ID;
the extractor receives related IDs or leaves an uncertain correction pending.
